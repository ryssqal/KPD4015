<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Buku</title>
    <style>
        body{
            background-color: pink;
        }
        img{
            width: 200px;
        }
        h1{
            font-family: calibri;
        }
        table{
            background-color: white;
        }
    </style>
</head>
<body>
<center>
    <img src="image.jfif">
    <h1>SENARAI NAMA BUKU</h1>
    <table border="1">
        <tr>
            <td>KOD BUKU</td>
            <td>NAMA BUKU</td>
            <td>JENIS BUKU</td>
            <td>HARGA BUKU</td>
            <td>TAHUN TERBITAN</td>
        </tr>
<?php
$papar = mysqli_query($conn,"SELECT * FROM jadualbuku");
while ($row=mysqli_fetch_array($papar)){
    echo"
    <tr>
        <td>".$row['kod_buku']."</td>
        <td>".$row['nama_buku']."</td>
        <td>".$row['jenis_buku']."</td>
        <td>".$row['harga_buku']."</td>
        <td>".$row['tahun_terbit']."</td>
    </tr>
    ";
}
?>
    </table>
</center>
</body>
</html>